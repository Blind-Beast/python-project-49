### Hexlet tests and linter status:
[![Actions Status](https://github.com/Blind-Beast/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Blind-Beast/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/caaee538cb8cd2e8e8b0/maintainability)](https://codeclimate.com/github/Blind-Beast/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/X3agme6w3K4T8wGJaX6Ac8LhZ.svg)](https://asciinema.org/a/X3agme6w3K4T8wGJaX6Ac8LhZ)
[![asciicast](https://asciinema.org/a/foeoDPbvJzwMp7VNdaW1QxY8j.svg)](https://asciinema.org/a/foeoDPbvJzwMp7VNdaW1QxY8j)
[![asciicast](https://asciinema.org/a/D9YDXd4YIkzwpVfM5Of3BKTWl.svg)](https://asciinema.org/a/D9YDXd4YIkzwpVfM5Of3BKTWl)
[![asciicast](https://asciinema.org/a/RXyzfCS8JfQ3DcyGTKPurO5Jb.svg)](https://asciinema.org/a/RXyzfCS8JfQ3DcyGTKPurO5Jb)